package com.wine.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface ProductAllTelImpl {
	public void productalltelImpl(HttpServletRequest request, HttpServletResponse response) throws Exception;

}
