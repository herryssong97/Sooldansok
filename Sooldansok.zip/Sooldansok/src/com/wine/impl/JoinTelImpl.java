package com.wine.impl;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface JoinTelImpl {
	public boolean jointelImpl(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
